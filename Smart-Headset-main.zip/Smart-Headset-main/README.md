# ESP32 Smart Obstacle Detection & Voice Guidance Robot

A smart obstacle detection system built using an **ESP32**, three **HC-SR04 ultrasonic sensors**, an **SSD1306 OLED display**, and **Bluetooth communication**. The system continuously monitors obstacles on the **left, centre, and right** sides and generates real-time movement commands.

## 🚀 Features

* 📡 Three-direction obstacle detection
* 📏 Adjustable obstacle detection range — currently **100 cm**
* 🧭 Intelligent movement decision:

  * `MOVE`
  * `MOVE LEFT`
  * `MOVE RIGHT`
  * `STOP`
* 🖥️ Real-time distance display on a 0.96" OLED
* 📱 Bluetooth communication with a mobile application
* 🔊 Voice guidance through the mobile app using Text-to-Speech
* ⚡ ESP32-based real-time processing
* 🔄 Sequential ultrasonic sensor reading to reduce interference

## 🧠 Decision Logic

| Left    | Centre  | Right   | Command    |
| ------- | ------- | ------- | ---------- |
| Clear   | Clear   | Clear   | MOVE       |
| Blocked | Clear   | Clear   | MOVE RIGHT |
| Clear   | Clear   | Blocked | MOVE LEFT  |
| Clear   | Blocked | Clear   | STOP       |
| Blocked | Blocked | Clear   | MOVE RIGHT |
| Clear   | Blocked | Blocked | MOVE LEFT  |
| Blocked | Clear   | Blocked | STOP       |
| Blocked | Blocked | Blocked | STOP       |

## 🔧 Hardware

* ESP32 Development Board
* 3 × HC-SR04 Ultrasonic Sensors
* 0.96" SSD1306 OLED Display
* 1kΩ + 2kΩ voltage dividers for HC-SR04 ECHO protection
* Breadboard and jumper wires
* Android smartphone for Bluetooth voice guidance

## 📌 Pin Configuration

| Component      |    TRIG |    ECHO |
| -------------- | ------: | ------: |
| Left HC-SR04   |  GPIO 5 | GPIO 18 |
| Centre HC-SR04 | GPIO 16 |  GPIO 4 |
| Right HC-SR04  | GPIO 17 | GPIO 19 |
| OLED SDA       | GPIO 21 |       — |
| OLED SCL       | GPIO 22 |       — |

## 📱 Mobile Communication

The ESP32 communicates with the mobile application through Bluetooth using the device name:

`ESP32_Obstacle`

The mobile application receives movement commands and can provide corresponding **voice instructions** using Text-to-Speech.

## 🎯 Project Goal

The goal of this project is to create a simple, low-cost and intelligent obstacle detection and navigation system capable of providing both **visual feedback and voice-based movement guidance** in real time.

## 🛠️ Technologies Used

* C++ / Arduino
* ESP32
* HC-SR04 Ultrasonic Sensors
* SSD1306 OLED
* Bluetooth
* MIT App Inventor
* Text-to-Speech

## 📄 License

This project is intended for educational, experimental, and robotics development purposes.
